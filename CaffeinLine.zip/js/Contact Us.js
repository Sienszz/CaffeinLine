/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function myFunction() {
    var x = document.getElementById("headerID");
    if (x.className === "header") {
      x.className += " responsive";
    } else {
      x.className = "header";
    }
  }

  function is_numeric(str){
    return /^\d+$/.test(str);
}

function validate(){
  var name = document.getElementById("name").value;
  var email = document.getElementById("email").value;
  var message = document.getElementById("message").value;
  var error_message = document.getElementById("error_message");

  error_message.style.padding = "10px";

  var text;
  if(name.length < 1){
    text = "Name Must Be Filled";
    error_message.innerHTML = text;
    return false;
  }

  if(email.indexOf("@")== -1){
    text = "Email is Invalid";
    error_message.innerHTML = text;
    return false;
  }

  if(message.length < 1){
    text = "Message Must be Filled";
    error_message.innerHTML = text;
    return false;
  }else if(message.length > 250){
    text = "Message length Cannot be Greater than 250"
    error_message.innerHTML = text;
    return false;
  }
  
  

  alert("Form Is Submitted!");
  return true;
}


