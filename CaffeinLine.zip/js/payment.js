/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function myFunction() {
    var x = document.getElementById("headerID");
    if (x.className === "header") {
      x.className += " responsive";
    } else {
      x.className = "header";
    }
  }

function validate(){
  var fname = document.getElementById("fname").value;
  var email = document.getElementById("email").value;
  var adr = document.getElementById("adr").value;
  var city = document.getElementById("city").value;
 
  // var x = document.form.payment-method;
  // var radio = document.getElementsByName("payment-method");
  // var valid = false;
  var cname = document.getElementById("cname").value;
  var ccnum = document.getElementById("ccnum").value;
  var expyear = document.getElementById("expyear").value;
  var cvv =  document.getElementById("cvv").value;
  var error_message = document.getElementById("error_message");
  var y = document.forms["payment-form"]["tandc"].checked;

  error_message.style.padding = "10px";

  var text;
  if(fname.length < 1){
    text = "Name Must Be Filled!";
    error_message.innerHTML = text;
    return false;
  }
  if(email.length < 1){
    text = "Email Must Be Filled!";
    error_message.innerHTML = text;
    return false;
  }else if(email.indexOf("@")== -1){
    text = "Email is Invalid!";
    error_message.innerHTML = text;
    return false;
  }

  if(adr.length < 1){
    text = "Address Must be Filled!";
    error_message.innerHTML = text ;
    return false;
  }

  if(city.length < 1){
    text = "City Must be Filled!";
    error_message.innerHTML = text ;
    return false;
  }

  if(cname.length < 1){
    text = "Credit Card Name Must be Filled!";
    error_message.innerHTML = text ;
    return false;
  }

  if(ccnum.length < 1){
    text = "Credit Card Number Must be Filled!";
    error_message.innerHTML = text;
    return false;
  }else if(isNaN(ccnum)){
    text = "Enter Valid Credit Card Number!";
    error_message.innerHTML = text;
    return false;
  }

  if(expyear.length < 1){
    text = "Credit Card Expiration Year Must be Filled!";
    error_message.innerHTML = text;
    return false;
  }else if(isNaN(ccnum) || expyear.length != 4){
    text = "Enter Valid Expiry Year!";
    error_message.innerHTML = text;
    return false;
  }else if(expyear < 2021){
    text = "Your Credit Card Have Expired!"
    error_message.innerHTML = text;
    return false;
  }

  if(cvv.length < 1){
    text = "CVV Number Must be Filled!";
    error_message.innerHTML = text;
    return false;
  }else if(isNaN(cvv) || cvv.length != 3){
    text = "Enter Valid CVV Number!";
    error_message.innerHTML = text;
    return false
  }

  if(!y){
    text = "You Must Accept the Terms and Conditions!";
    error_message.innerHTML = text;
    return false;
  }

  alert("Form Is Submitted!");
  return true;
}


