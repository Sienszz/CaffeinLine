function headerFunc() {
    var x = document.getElementById("headerID");
    if (x.className === "header") {
      x.className += " resp";
    } else {
      x.className = "header";
    }
  }
  /* ============================ Header =============================*/