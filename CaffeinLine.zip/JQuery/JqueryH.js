  $.JQueryFout = function(){
    $('.slideIMG').fadeOut(500);
  };
  $.JQueryFin = function(){
    $('.slideIMG').fadeOut(0).fadeIn(1000);
  };
  // =================================================================== 
$(function() {
    var currentSlide = 1;
    var $slider = $('#slider');
    var $slideContainer = $slider.find('.AllSlideImg');
    var $slides = $slideContainer.find('.SlideImg');

    setInterval(function(){
      $slideContainer.animate({'margin-left': '-=99vw'},1000, function() {
        currentSlide++;
        if (currentSlide === $slides.length) {
            currentSlide = 1;
            $slideContainer.css('margin-left', 0);
        }
      });
    },5000);
  });

  